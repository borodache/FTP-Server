package server;
import java.io.*;
import java.lang.Thread.State;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import state.StateGetOut;
import util.*;

public class FTPParallelServer
{
//	public static ITracer ms_tracer;
	public static void main(String[] args)
	{
		String property = System.getProperty("ftp.tracer", "util.Tracer");
		ITracer myObject = null;
		try {
			Class myClass =  Class.forName(property);
			myObject = (ITracer)myClass.newInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Tracer.setInstance((ITracer) myObject);
		ParallelServerImp psi = new ParallelServerImp();
		psi.goMain();
	}
}

class ParallelServerImp //implements Runnable
{
	//fields
	private ServerSocket m_ss;

	public void goMain()
	{
		Tracer.getInstance().printMessage("Parallel Server Program");
		ExecutorService es = Executors.newFixedThreadPool(3, Executors.defaultThreadFactory());
		
		try
		{
			// TODO make port configurable
			m_ss = new ServerSocket(21);
			while (true)
			{
				final Socket s = m_ss.accept();
				//  TODO Executors

				SessionContext sc = new SessionContext(s);
				es.execute(new SessionHandler(sc));
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

class SessionHandler implements Runnable 
{
	static int ms_current = 1;
	SessionContext m_sessionContext;
	String m_name;
	public SessionHandler(SessionContext sc) 
	{
		// TODO Auto-generated constructor stub
		m_sessionContext = sc;
		m_name = "session-" + sc.getUserSocket().getRemoteSocketAddress() + ", " +  ms_current++;
	}
	
	public void run()
	{
		Thread.currentThread().setName(m_name);
		Tracer.getInstance().printMessage("thread: " + m_name);
		try {
			m_sessionContext.sendMessageToClient(Constants.ErrorCodeWelcome);
		} catch (OutputException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		state.State state = null;
		while(state != new StateGetOut())
		{
			try 
			{
				state = m_sessionContext.goNext();
	//			Tracer.getInstance().printMessage("Session with: " + m_sessionContext.getUserName() + "was finished");
			}
			catch (IOException e)
			{
				Tracer.getInstance().printMessage("Session with: " + m_sessionContext.getUserName() + " was terminated. IOException!" + Constants.CRLF);
				e.printStackTrace();
				break;
			}
		}
	}
}
