package server;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

import state.*;
import util.Constants;
import util.IErrorCode;
import util.InputException;
import util.OutputException;
import util.Tracer;
import util.Utilities;

public class SessionContext 
{
	/**
	 * this is for tracing and debugging
	 */
	private String m_userName;
	private State m_userState;
	/**
	 * Socket returned by accept()
	 * Used for messages to send to client and to listen for requests from client
	 */
	private Socket m_userSocket;
	private boolean dataPipe = false;
	/**
	 * to send data we need one more socket according to FTP RFC
	 * client will listen on port defined by FTP RFC
	 * we get IP & port from Port command
	 * (client will open ServerSocket for listen) on this IP:port
	 */
	private InetAddress m_ipAddress;
	private Integer m_portAddress;
	/**
	 * Each user may ask files from different directories
	 */
	private File workingDirectory = new File("C:/Users/Eli/Desktop/Job");
//	private File workingDirectory = new File("C:/Users/Eli/workspace/Java");
	// The most important method
	public State goNext() throws InputException, OutputException
	{
		m_userState.goNext(this);
		return this.getState();
	}
	
	//TODO Timer
	public String sendGetMsg(IErrorCode ec) throws InputException, OutputException, SocketTimeoutException 
	{
		String msg = ec.getId() + " - Eli's Server Says: " + ec.getMsgToClient() + Constants.CRLF;
		return sendGetMsg(msg);
	}

	private String sendGetMsg(String msg) throws InputException, OutputException, SocketTimeoutException 
	{
		sendMessageToClient(msg);
		String input = getMessageFromClient();
		return input;
	}
	
	public String getMessageFromClient() throws InputException, SocketTimeoutException
	{
		byte[] byteArrayInput = new byte[1024];
		int iSizeOfInput;
		try {
			iSizeOfInput = m_userSocket.getInputStream().read(byteArrayInput);
		} 
		catch (SocketTimeoutException e)
		{
			throw new SocketTimeoutException();
		}
		catch (IOException e) {
			throw new InputException();
		}
		byte[] byteArrayInputWithoutTrash = Utilities.CutByteArray(byteArrayInput, iSizeOfInput);
		String strRet = Utilities.convertByteArrayToString(byteArrayInputWithoutTrash);
		Tracer.getInstance().printMessage(">> input: " + strRet);
		return strRet;
	}

	private void sendMessageToClient(String strMsg) throws OutputException
	{
		try {
			m_userSocket.getOutputStream().write(strMsg.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new OutputException();
		}
	}
	
	public void sendMessageToClient(IErrorCode ec) throws OutputException
	{
		String msg = ec.getId() + " - Eli's Server Says: " + ec.getMsgToClient() + Constants.CRLF;
		sendMessageToClient(msg);
	}

	// set&get methods
	public State setState(State newState)
	{
		State oldState = m_userState;
		m_userState = newState;
		return oldState;
	}
	
	public State getState()
	{
		return m_userState;
	}
	
	public void setUserName(String userName)
	{
		m_userName = Utilities.cutCRLFFromString(userName);
	}
	
	public String getUserName()
	{
		return m_userName;
	}
	
	public Socket getUserSocket()
	{
		return m_userSocket;
	}
	
	public SessionContext(Socket userSocket)
	{
		m_userSocket = userSocket;
		m_userState = new StateNotConnectedNoUser();
	}

	public void setWorkingDirectory(File workingDirectory) {
		this.workingDirectory = workingDirectory;
	}

	public File getWorkingDirectory() {
		return workingDirectory;
	}

	public void setIpAddress(InetAddress address) {
		this.m_ipAddress = address;
	}

	public InetAddress getIpAddress() {
		return m_ipAddress;
	}

	public void setPortAddress(Integer PortAddress) {
		this.m_portAddress = PortAddress;
	}

	public Integer getPortAddress() {
		return m_portAddress;
	}

	public boolean getDataPipe() {
		return dataPipe;
	}
	
	public void setDataPipe(boolean dataPipe) {
		this.dataPipe = dataPipe;
	}

	public boolean isDataPipe() {
		return dataPipe;
	}
}
