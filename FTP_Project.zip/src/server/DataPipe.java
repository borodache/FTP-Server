package server;

import java.io.IOException;
import java.net.Socket;

import util.Constants;
import util.DataSocketInvalidException;
import util.ErrorCode;
import util.OutputException;
import util.Tracer;

public class DataPipe extends Thread implements Runnable 
{
	SessionContext sc; 
	ErrorCode ec;
	Socket dataSocket;
	
	public DataPipe(SessionContext sc, ErrorCode ec) throws DataSocketInvalidException 
	{
		this.sc = sc;
		this.ec = ec;
		try {
			this.dataSocket = new Socket(sc.getIpAddress(), sc.getPortAddress());
		} catch (IOException e) {
			throw new DataSocketInvalidException();
		}
	}

	public void run()
	{
		Tracer.getInstance().printMessage("Data Pipe runs on " + Thread.currentThread());
		sc.setDataPipe(true);
		boolean ret = true;
		try
		{
			sc.sendMessageToClient(Constants.ErrorCodeDataPipeOpen);
			dataSocket.getOutputStream().write(ec.getByteMsgToClient());
			dataSocket.close();
			sc.sendMessageToClient(Constants.dynamicErrorCode(226, "Directory send OK."));
		} 
		catch (IOException e) 
		{
			Tracer.getInstance().printMessage("IOE Exception");
			try {
				sc.sendMessageToClient(Constants.ErrorCodeCommandNotImplemnted);
			} catch (OutputException e1) {
				// There is nothing we can do.
				Tracer.getInstance().printMessage("IOE Exception in main channel with client");
			}
			ret = false;
		}
		sc.setDataPipe(false);
		if (ret)
		{
			try {
				sc.sendMessageToClient(Constants.ErrorCodeCommandOk);
			} catch (OutputException e) {
				// There is nothing we can do.
			}
		}
		Tracer.getInstance().printMessage("It's Time to live Data Pipe...");
	}
}
