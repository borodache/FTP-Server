package util;

public interface ITracer {
//	final String str = "100";
	public void printMessage(String strMsg);
}
