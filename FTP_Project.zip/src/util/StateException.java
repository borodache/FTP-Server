package util;

public class StateException extends Exception {

}
