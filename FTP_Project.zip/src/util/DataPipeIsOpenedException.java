package util;

public class DataPipeIsOpenedException extends Exception 
{

}
