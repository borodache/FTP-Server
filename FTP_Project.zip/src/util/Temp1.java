package util;

public abstract class Temp1 {
	void m()
	{
		m2();
	}
	abstract void m2();	

	static void m3()
	{
		
	}
}

class Temp2 extends Temp1
{
	void m2()
	{
		m3();
	}
	static void m3()
	{
		
	}
}
