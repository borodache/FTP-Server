package util;

public class SyntaxException extends Exception {

}
