package util;

public class ErrorCode implements IErrorCode
{
	private int id;
	private String msgToClient;
	private byte[] msgArrByteToClient;

	
	@Override
	public int getId() {
		return id;
	}
	@Override
	public String getMsgToClient() {
		return msgToClient;
	}
	public byte[] getByteMsgToClient() {
		if(msgArrByteToClient == null)
			return msgToClient.getBytes();
		return msgArrByteToClient;
	}
	
	ErrorCode(int id, String msgToClient) 
	{
		this.setId(id);
		this.setMsgToClient(msgToClient);
	}
	ErrorCode(int id, byte[] msgToClient) 
	{
		this.setId(id);
		this.setMsgToClient(msgToClient);
	}
	private void setMsgToClient(String msgToClient) 
	{
		this.msgToClient = msgToClient;
	}
	private void setMsgToClient(byte[] msgToClient) 
	{
		this.msgArrByteToClient = msgToClient;
	}
	private void setId(int id) 
	{
		this.id = id;
	}
}
