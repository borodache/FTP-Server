package util;

public interface IErrorCode 
{
//	public String getName();
	public int getId();
	public String getMsgToClient();
}
