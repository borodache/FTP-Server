package util;

/*
public class LoginUserException extends Exception
{
	int m_errorCode;
	public LoginUserException()
	{
		m_errorCode = 501;
	}
	public LoginUserException(int ftpErrorCode)
	{
		super();
		m_errorCode = ftpErrorCode;
	}
	public int getFtpErrorCode()
	{
		return m_errorCode;
	}
}
*/