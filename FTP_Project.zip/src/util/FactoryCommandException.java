package util;

public class FactoryCommandException extends Exception {

}
