package util;

import java.io.IOException;

public class InputException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 0;
/*	static InputException m_ie;
	public static InputException getInstance()
	{
		return m_ie;
	}
	
	public InputException() {
		m_ie = this;
	}*/
}
