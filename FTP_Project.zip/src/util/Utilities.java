package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

public class Utilities 
{	
	public static byte[] copySecondByteArrayToFirstByteArray(byte[] firstByteArray, byte[] secondByteArray)
	{
		if (firstByteArray == null)
			return secondByteArray;
		if (secondByteArray == null)
			return firstByteArray;
		
		int len = firstByteArray.length + secondByteArray.length;
		byte[] retByteArray = new byte[len];
		for(int i = 0; i < firstByteArray.length; i++)
		{
			retByteArray[i] = firstByteArray[i];
		}
		for(int i = firstByteArray.length, j = 0; j < secondByteArray.length; i++, j++)
		{
			retByteArray[i] = secondByteArray[j];
		}
		return retByteArray;
	}

	public static Integer parseStringIntoAnInteger(String str)
	{
		return Integer.parseInt(str);
	}

	public static Integer[] parseStringIntoAnIntegersArray(String str)
	{
		String[] arrayOfStr = str.split(",");
		Integer[] arrayOfInteger = new Integer[arrayOfStr.length];
		for(int i = 0; i < arrayOfInteger.length; i++)
			arrayOfInteger[i] = parseStringIntoAnInteger(arrayOfStr[i]);
		return arrayOfInteger;
	}

	public static int getNumOfWordsInString(String str)
	{
		if (str == null)
			return 0;
		String[] arrayOfStr = str.split(" ");
		return arrayOfStr.length;
	}

	public static String cutCRLFFromString(String str)
	{
		if (str == null)
			return null;
		if (str.endsWith(Constants.CRLF))
			str = str.substring(0, str.length() - 2);
		return str;
	}

	public static String parseStringIntoCommand(String str)
	{
		return cutCRLFFromString(getWordFromString(str, 0));
	}

	public static String parseStringIntoData(String str)
	{
		int numOfWords = getNumOfWordsInString(str);
		if (numOfWords < 2)
		{
			return null;
		}
		String data = getWordFromString(str, 1);
		for (int i = 2; i < numOfWords; i++)
		{
			data = data + getWordFromString(str, i);
		}
		return data;
	}

	public static String getWordFromString(String str, int location)
	{
		String[] arrayOfStr = str.split(" ");
		if (location > arrayOfStr.length)
		{
			// TODO ERROR!
			return null;
		}
		return cutCRLFFromString(arrayOfStr[location]);
	}

	public static String convertByteArrayToString(byte[] byteArray)
	{
		String strRet;
		strRet = new String(byteArray); //, "ISO-8859-1");
		return strRet;
	}

	public static byte[] CutByteArray(byte[] byteArray, int iNewLenght)
	{
		if (iNewLenght >= byteArray.length)
			return byteArray;
		byte[] byteArrayRet = new byte[iNewLenght];
		for(int i = 0; (i < iNewLenght); i++)
		{
			byteArrayRet[i] = byteArray[i];
		}
		return byteArrayRet;
	}
	
	public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    }	
}
