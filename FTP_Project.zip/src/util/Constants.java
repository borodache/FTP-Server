package util;

import command.FactoryCommand;

public class Constants 
{
	//public static final IErrorCode ErrorCodeCommandNotOk = null;

	public static String CRLF = "\r\n";
	
	public static FactoryCommand factoryComand = new FactoryCommand();

//	Error Code of States
	public static IErrorCode ErrorCodeCommandOk = new ErrorCode(200, "Ok");
	public static IErrorCode ErrorCodeWelcome = new ErrorCode(220, "Welcome!");
	public static IErrorCode ErrorCodeUserNotOk = new ErrorCode(501, "Unknown user name");
	public static IErrorCode ErrorCodeUserOk = new ErrorCode(331, "Username is Ok, now Enter PassWord");
	public static IErrorCode ErrorCodePswNotOk = new ErrorCode(530, "The Password You enterd is incorrect");
	public static IErrorCode ErrorCodePswOk = new ErrorCode(230, "You are logged in!");
	public static IErrorCode ErrorCodeGoodBye = new ErrorCode(221, "GoodBye! Have a nice day!");
	public static IErrorCode ErrorCodeDataPipeOpen = new ErrorCode(125, "Data connection already open; transfer starting.");
	
	
// Error code of Errors
	public static IErrorCode ErrorCodeSyntaxErrorCommandUnRecognized = new ErrorCode(500, "Syntax error, command unrecognized.");
	public static IErrorCode ErrorCodeSyntaxError = new ErrorCode(501, " Syntax error in parameters or arguments.");
	public static IErrorCode ErrorCodeCommandNotImplemnted = new ErrorCode(502, "Command not implemented.");
	public static IErrorCode ErrorCodeBadCommandSequence = new ErrorCode(503, "Bad sequence of commands.");
	public static IErrorCode ErrorCodeUnableDataChannel = new ErrorCode(505, "Mistake in address or port");
	
	public static ErrorCode dynamicErrorCode(int id, String msgToClient)
	{
		return new ErrorCode(id, msgToClient);
	}
	
	public static ErrorCode dynamicErrorCode(int id, byte[] msgToClient)
	{
		return new ErrorCode(id, msgToClient);
	}

}
