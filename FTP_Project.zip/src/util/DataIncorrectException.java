package util;

public class DataIncorrectException extends Exception 
{
	
}
