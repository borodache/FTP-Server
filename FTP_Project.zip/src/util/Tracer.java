package util;

public class Tracer implements ITracer
{
	static ITracer ms_tracer;

	public void printMessage(String strMsg)
	{
		System.err.println(strMsg);
	}

	public static void setInstance(ITracer t)
	{
		ms_tracer = t;
	}

	public static ITracer getInstance()
	{
		return ms_tracer;
	}
}
