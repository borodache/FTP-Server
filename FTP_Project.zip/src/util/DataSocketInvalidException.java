package util;

public class DataSocketInvalidException extends Exception {

}
