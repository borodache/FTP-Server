package util;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;


public class GuiTracer extends Tracer implements ActionListener
{
	JFrame frame;
	JTextArea text;
	JScrollPane scroll;
	int maxStrLen = 0;

	public GuiTracer() 
	{
		init();
	}

	public void printMessage(String strMsg)
	{
//		text.getCaretPosition();
		
//		String str = text.getText();
		if(!strMsg.endsWith("\n"))
			strMsg += "\n";
		if (strMsg.length() > maxStrLen)
			maxStrLen = strMsg.length();
//		System.err.println(scroll.getAlignmentY());
		//str = str + strMsg;
		Color c = Color.black;
/*		if(strMsg.startsWith(">>"))
		{
			c = Color.green;
		}
		else if(strMsg.startsWith("<<"))
		{
			c = Color.blue;
		}*/

		StyleContext sc = StyleContext.getDefaultStyleContext();
	    AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

	    int len = text.getDocument().getLength(); // same value as
	                       // getText().length();
//	    text.setCharacterAttributes(aset, false);
//	    text.replaceSelection(str); // there is no selection, so inserts at caret
		//text.setText(str);
		text.append(strMsg);
	    text.setCaretPosition(len); // place caret at the end (with no selection)
//		scroll.setAlignmentY(0);
//		scroll.setAlignmentY((float) scroll.getPreferredSize().getHeight());
	}

	public static void setInstance(ITracer t)
	{
		ms_tracer = t;
	}

	public static ITracer getInstance()
	{
		return ms_tracer;
	}

	private void init()
	{
		frame = new JFrame();
		frame.setLayout(new GridBagLayout());
	    text = new JTextArea();
	    text.setEditable(false);
//	    text.getS
	    scroll = new JScrollPane(text)
	    {
	    	/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
	    	public Dimension getPreferredSize()
	    	{
	    		java.awt.Rectangle rootPaneBounds = frame.getRootPane().getBounds();
    			return new Dimension(rootPaneBounds.width,rootPaneBounds.height);
	    	}
			
/*			@Override
		    public JViewport getViewport()
		    {
//				setL(BOTTOM_ALIGNMENT);
				System.err.println(viewport.getAlignmentY());
				viewport.setAlignmentY(BOTTOM_ALIGNMENT);
				return viewport;
		    }*/
	    };
//	    scroll.setC
	    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
	    frame.add(scroll);
	    frame.setSize(200, 600);
	    frame.setVisible(true);
	   }

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		// TODO Auto-generated method stub
//		printMessage("Button shut down!");
		printMessage("action!");
	}
}
