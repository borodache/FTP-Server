package util;

import java.io.IOException;

public class OutputException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/*	static InputException m_ie;
	public static InputException getInstance()
	{
		return m_ie;
	}
	
	public InputException() {
		m_ie = this;
	}*/
}
