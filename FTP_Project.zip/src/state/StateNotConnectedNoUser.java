package state;

import server.SessionContext;
import util.Constants;
import util.OutputException;

public class StateNotConnectedNoUser extends StateNotConnected
{
//	protected Command[] optinalCommands = {CommandUser};

	@Override
	protected void handleDataIncorrectException(SessionContext sc) throws OutputException 
	{
		// TODO Auto-generated catch block
		sc.sendMessageToClient(Constants.ErrorCodeUserNotOk);
	}
		
/*	//(StateException e)
	{
		// TODO!!!
	}*/
}
