package state;

import server.SessionContext;
import util.Constants;
import util.OutputException;

public class StateNotConnectedHasUserNoPsw extends StateNotConnected 
{
	int retries = 0;

	@Override
	void handleDataIncorrectException(SessionContext sc) throws OutputException 
	{
		// TODO Auto-generated method stub
		sc.sendMessageToClient(Constants.ErrorCodePswNotOk);
		sc.setState(new StateNotConnectedNoUser());
		sc.setUserName(null);
	}
}