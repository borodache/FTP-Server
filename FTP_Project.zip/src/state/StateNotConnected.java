package state;

abstract public class StateNotConnected extends State 
{
}
