package state;

import java.net.SocketTimeoutException;

import command.ICommand;

import server.SessionContext;
import util.Constants;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.FactoryCommandException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Tracer;
import util.Utilities;

public abstract class State
{
	public State goNext(SessionContext sc) throws InputException, OutputException 
	{
		try
		{
			String input = sc.getMessageFromClient();
			ICommand cmd = Constants.factoryComand.factory(input, sc);
			cmd.perform();
		}
		catch (SyntaxException e) {
			sc.sendMessageToClient(Constants.ErrorCodeSyntaxError);
		} catch (DataIncorrectException e) {
			handleDataIncorrectException(sc);
		} catch (StateException e) {
			sc.sendMessageToClient(Constants.ErrorCodeBadCommandSequence);
		}
		catch (DataPipeIsOpenedException e){
			sc.sendMessageToClient(Constants.ErrorCodeBadCommandSequence);
		}
		catch (DataSocketInvalidException e)
		{
			sc.sendMessageToClient(Constants.ErrorCodeUnableDataChannel);
		}
		catch (FactoryCommandException e) {
			sc.sendMessageToClient(Constants.ErrorCodeSyntaxErrorCommandUnRecognized);
		} catch (SocketTimeoutException e) {
			Tracer.getInstance().printMessage("Timed Out: " + sc.getUserName());
			sc.sendMessageToClient(Constants.ErrorCodeGoodBye);
			new StateGetOut().goNext(sc);
			return new StateGetOut();
		}
		return (this);
		//sc.goNext();
	}
	
	abstract void handleDataIncorrectException(SessionContext sc) throws OutputException;

//	protected static boolean validateSyntaxOfInput(String input)
//	{
//		// TODO change the Assumption to commands with no data (only 1 part) and etc
//		// Assumption = the input string is comprised from 2 parts
//		input = Utilities.cutCRLFFromString(input);
//		String command = Utilities.parseStringIntoCommand(input);
//		String data = Utilities.parseStringIntoData(input);
//		if (command.equalsIgnoreCase(null) || data.equalsIgnoreCase(null))
//		{
//			return false;
//		}
//		return true;
//	}
}
