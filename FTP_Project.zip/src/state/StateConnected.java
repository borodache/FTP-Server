package state;

import server.SessionContext;
import util.*;

public class StateConnected extends State 
{
	@Override
	void handleDataIncorrectException(SessionContext sc) throws OutputException 
	{
		sc.sendMessageToClient(Constants.dynamicErrorCode(540, "Invalid Data!"));
	}
}