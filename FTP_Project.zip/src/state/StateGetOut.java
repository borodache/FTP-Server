package state;

import server.SessionContext;
import util.OutputException;

public class StateGetOut extends State 
{
	public State goNext(SessionContext sc)
	{
		return this;
		// Get Out
		
	}

	@Override
	void handleDataIncorrectException(SessionContext sc) throws OutputException {
		// No Need in this method at this state
		
	}
}
