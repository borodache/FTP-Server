
public class Singletone {
	private static Singletone ms_single;
	private Singletone()
	{
	}

	public static Singletone getInstance()
	{
			if(ms_single == null)
			{
				synchronized (Singletone.class) 
				{
					if(ms_single == null)
						ms_single = new Singletone();
				}
			}
			return ms_single;
	}	
}

class Singletone2
{
	private static Singletone2 ms_single = new Singletone2();
	private Singletone2()
	{
	}

	public static Singletone2 getInstance()
	{
		return ms_single;
	}

}