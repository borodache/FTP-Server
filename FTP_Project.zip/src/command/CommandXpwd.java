package command;

import java.io.File;

import server.SessionContext;
import state.StateConnected;
//import state.StateConnectedWorking;
import util.Constants;
import util.InputException;
import util.OutputException;
import util.StateException;

public class CommandXpwd extends Command{

	static protected Class<?>[] arrayOfPossibleStateClasses = {StateConnected.class};

	public CommandXpwd(String data, SessionContext sc) 
	{
		super(data, sc);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void perform() throws StateException ,OutputException ,InputException
	{
		validateState();
		validate();
		SessionContext sc = this.getSessionContext();
		File folder = sc.getWorkingDirectory();
		String msg = "Working Directory:" + Constants.CRLF + folder + Constants.CRLF;
/*		for(int i = 0; i < folder.listFiles().length; i++)
		{
			msg = msg + ".." + folder.listFiles()[i].getName();
			if (i < (folder.listFiles().length - 1))
				msg = msg + Constants.CRLF;
		}*/
		sc.sendMessageToClient(Constants.dynamicErrorCode(212,msg));
//		sc.setState(new StateConnectedWorking());
	}

	@Override
	protected void validate() //throws SyntaxException, DataIncorrectException
	{
//		boolean b1 = (getData().equals(null));
//		boolean b2 = (getSessionContext().getState().getClass() == StateConnected.class);
		//return (b1 && b2);
	}
}
