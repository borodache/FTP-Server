package command;

import server.SessionContext;
import state.StateConnected;
import state.StateNotConnectedHasUserNoPsw;
import util.Constants;
import util.DataIncorrectException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Utilities;

public class CommandPass extends Command implements ICommand 
{
	static protected Class<?>[] arrayOfPossibleStateClasses = {StateNotConnectedHasUserNoPsw.class};
	
	public CommandPass(String data, SessionContext sc) 
	{
		super(data, sc);
	}
	
	@Override
	// returns true if the psw is validate
	protected void validate() throws SyntaxException, DataIncorrectException
	{
		String psw = this.getData();
		if ((Utilities.getNumOfWordsInString(psw) > 2) || (psw.equals(null)))
		{
			// username can be only one name!
			throw new SyntaxException();
		}
		if (!("" + psw.charAt(0)).equalsIgnoreCase("e"))
		{
			throw new DataIncorrectException();
		}
	}
	
	@Override
	// performs action and returns true if the action performed
	public void perform() throws SyntaxException, DataIncorrectException, StateException, InputException, OutputException
	{
		validateState();
		validate();
		getSessionContext().setState(new StateConnected());
		getSessionContext().sendMessageToClient(Constants.ErrorCodePswOk);
	}
}
