package command;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import server.DataPipe;
import server.SessionContext;
import util.Constants;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Tracer;
import util.Utilities;

public class CommandRetr extends Command {

	public CommandRetr(String data, SessionContext sc) {
		super(data, sc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void validate() throws SyntaxException, DataIncorrectException,
			DataPipeIsOpenedException {
		// TODO Auto-generated method stub
		String data = getData();
		if (Utilities.getNumOfWordsInString(data) != 1)
			throw new SyntaxException();
		File file = new File(data);
		if (!file.isFile())
		{
			{
				file = new File(getSessionContext().getWorkingDirectory() + "/" + data);
				if (!file.isFile())
				{
					throw new DataIncorrectException();
				}
				setData(file.getPath());
			}
		}
		if (getSessionContext().getDataPipe())
		{
			throw new DataPipeIsOpenedException();
		}
	}

	@Override
	public void perform() throws SyntaxException, DataIncorrectException,
			StateException, OutputException, InputException,
			DataPipeIsOpenedException, DataSocketInvalidException {
		// TODO Auto-generated method stub
		validateState();
		validate();
		
		String data = getData();
		SessionContext sc = this.getSessionContext();
		File file = new File(data);
		byte[] msgFileContentBytes = null;

		try {
			//dis = new DataInputStream(new FileInputStream(file));
			msgFileContentBytes = Utilities.getBytesFromFile(file);
		} catch (FileNotFoundException e) {
			throw new DataIncorrectException();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try
//		{
//		FileOutputStream fos = new FileOutputStream(new File(data + ".ftp.doc"));
//		fos.write(msgFileContentBytes);
//		fos.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		//String msg = Utilities.convertByteArrayToString(msgArrayBytes);
		Tracer.getInstance().printMessage("We are Sending " + file.getName() + " to the client in data pipe\n");
		//DataPipe td = new DataPipe(sc, Constants.dynamicErrorCode(212,msg));
		DataPipe td = new DataPipe(sc, Constants.dynamicErrorCode(212,msgFileContentBytes));
		td.start();
	}

//public void performBad() throws SyntaxException, DataIncorrectException,
//	StateException, OutputException, InputException,
//	DataPipeIsOpenedException, DataSocketInvalidException {
//// TODO Auto-generated method stub
//validateState();
//validate();
//
//String data = getData();
//SessionContext sc = this.getSessionContext();
//File file = new File(data);
//// TODO Change this! it is just for now!!!
//FileInputStream fis;
//DataInputStream dis;
//try {
//	//dis = new DataInputStream(new FileInputStream(file));
//	fis = new FileInputStream(file);
//	dis = new DataInputStream(fis);
//	BufferedReader br = new BufferedReader(new InputStreamReader(dis));
//	String strLine;
//		while ((strLine = br.readLine()) != null)   {
//			  // Print the content on the console
//			  System.out.println (strLine);
//	}
//	String msgArrayBytes = strLine;
//} catch (FileNotFoundException e) {
//	throw new DataIncorrectException();
//}
//catch (IOException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//}
//
///*		byte[] fisArrayBytes = new byte[1024];
//byte[] tmpArrayBytes = null;
//byte[] msgArrayBytes = null;
//int len = 0;
//try {
//	for(len = fis.read(fisArrayBytes); ((len > 0) && (len <= 1024)); len = fis.read(fisArrayBytes))
//	{
//		tmpArrayBytes = Utilities.CutByteArray(fisArrayBytes, len);
//		msgArrayBytes = Utilities.copySecondByteArrayToFirstByteArray(msgArrayBytes, tmpArrayBytes);
//	}
//	fis.close();
//	FileOutputStream fos = new FileOutputStream(new File(data + ".ftp.doc"));
//	fos.write(msgArrayBytes);
//	fos.close();
//} catch (IOException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//}
//*/
////String msg = Utilities.convertByteArrayToString(msgArrayBytes);
//Tracer.getInstance().printMessage("We are Sending " + file.getName() + " to the client in data pipe\n");
////DataPipe td = new DataPipe(sc, Constants.dynamicErrorCode(212,msg));
//DataPipe td = new DataPipe(sc, Constants.dynamicErrorCode(212,msgArrayBytes));
//td.start();
//}

}
