package command;

import java.io.IOException;

import server.SessionContext;
import state.StateGetOut;
import util.Constants;
import util.StateException;
import util.Tracer;

public class CommandQuit extends Command 
{
	static protected Class<?>[] arrayOfPossibleStateClasses = null;
	
	public CommandQuit(String data, SessionContext sc) 
	{
		super(data, sc);
	}
	
	@Override
	public void perform() throws StateException
	{
		// GoodBye
		validateState();
		validate();
		try {
			this.getSessionContext().sendMessageToClient(Constants.ErrorCodeGoodBye);
			this.getSessionContext().getUserSocket().close();
		}
		catch (IOException e)
		{
			// Do nothing the connection was terminated anyway
		}
		Tracer.getInstance().printMessage("User: " + this.getSessionContext().getUserName() + ", left us");
		this.getSessionContext().setState(new StateGetOut());
	}

	@Override
	protected void validate()  
	{
		// Do nothing You can Quit in any time
	}
}
