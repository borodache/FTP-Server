package command;

import java.net.InetAddress;
import java.net.UnknownHostException;

import server.SessionContext;
import state.StateConnected;
import util.Constants;
import util.DataIncorrectException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Utilities;

public class CommandPort extends Command {

	static protected Class<?>[] arrayOfPossibleStateClasses = {StateConnected.class};
	
	public CommandPort(String data, SessionContext sc) 
	{
		super(data, sc);
	}
	
	@Override
	protected void validate() throws SyntaxException, DataIncorrectException {
		String data = getData();
		if (data == null)
			throw (new SyntaxException());
		Integer[] adrAndPort = Utilities.parseStringIntoAnIntegersArray(data);
		if (adrAndPort.length != 6)
			throw (new DataIncorrectException());
	}

	@Override
	public void perform() throws SyntaxException, DataIncorrectException,
			StateException, OutputException, InputException {
		validateState();
		validate();
		Integer[] adrAndPort = Utilities.parseStringIntoAnIntegersArray(getData());
		String addr = "" + adrAndPort[0] + "." + adrAndPort[1] + "." + adrAndPort[2] + "." + adrAndPort[3]; 
		InetAddress address = null;
		try {
			address = InetAddress.getByName(addr);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		Integer port = adrAndPort[4]*256 + adrAndPort[5];
		getSessionContext().setIpAddress(address);
		getSessionContext().setPortAddress(port);
		getSessionContext().sendMessageToClient(Constants.ErrorCodeCommandOk);
	}
}
