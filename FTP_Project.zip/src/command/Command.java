package command;

import server.SessionContext;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;

abstract public class Command implements ICommand {
	private SessionContext m_sc;
	private String m_data;
	
	static protected Class<?>[] arrayOfPossibleStateClasses;

	abstract protected void validate() throws SyntaxException, DataIncorrectException, DataPipeIsOpenedException;
	@Override
	abstract public void perform() throws SyntaxException, DataIncorrectException, StateException, OutputException, InputException, DataPipeIsOpenedException, DataSocketInvalidException;
	
	protected void validateState() throws StateException {
		if (arrayOfPossibleStateClasses == null)
			return;
		boolean b = false;
		for(int i = 0; i < arrayOfPossibleStateClasses.length; i++)
		{
			if (getSessionContext().getState().getClass() == arrayOfPossibleStateClasses[i])
				b = true;
		}
		if (!b)
			throw new StateException();
	}

	public Command(String data, SessionContext sc)
	{
		setData(data);
		setSessionContext(sc);
	}

	@Override
	public void setData(String data) 
	{
		m_data = data;
	}
	
	@Override
	public String getData() 
	{
		return m_data;
	}

	@Override
	public void setSessionContext(SessionContext sc) 
	{
		m_sc = sc;
	}
	
	@Override
	public SessionContext getSessionContext() 
	{
		return m_sc;
	}
}
