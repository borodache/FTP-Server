package command;

import server.SessionContext;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;

public interface ICommand 
{
	String getData();
	void setData(String Data);
	SessionContext getSessionContext();
	void setSessionContext(SessionContext sc);
	void perform() throws SyntaxException, DataIncorrectException, StateException, OutputException, InputException, DataPipeIsOpenedException, DataSocketInvalidException;;
}
