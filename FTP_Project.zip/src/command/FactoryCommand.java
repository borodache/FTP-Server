package command;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import server.SessionContext;
import util.FactoryCommandException;
import util.Utilities;

public class FactoryCommand 
{
	public ICommand factory(String str, SessionContext sc) throws FactoryCommandException
	{
		// TODO
		// Command PORT - will be returned as Port
		// Command GET - will be returned as Get and so on		
		String strCmd = Utilities.parseStringIntoCommand(str);
		strCmd = "" + strCmd.charAt(0) + strCmd.substring(1).toLowerCase();
		String strData = Utilities.parseStringIntoData(str);

		Command cmd = null;	
		// recognize command and checks syntax only
		Constructor<?> c;
		try {
			c = Class.forName("command.Command" + strCmd).getConstructor(new Class[]{String.class, SessionContext.class});
		} catch (SecurityException e) {
			throw new FactoryCommandException();
		} catch (NoSuchMethodException e) {
			throw new FactoryCommandException();
		} catch (ClassNotFoundException e) {
			throw new FactoryCommandException();
		}
		try {
			cmd = (Command) c.newInstance(new Object[]{strData, sc});
		} catch (IllegalArgumentException e) {
			throw new FactoryCommandException();
		} catch (InstantiationException e) {
			throw new FactoryCommandException();
		} catch (IllegalAccessException e) {
			throw new FactoryCommandException();
		} catch (InvocationTargetException e) {
			throw new FactoryCommandException();
		}
		return cmd;
	}
}
