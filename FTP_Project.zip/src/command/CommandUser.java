package command;

import server.SessionContext;
import state.StateNotConnectedHasUserNoPsw;
import state.StateNotConnectedNoUser;
import util.Constants;
import util.DataIncorrectException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Utilities;

public class CommandUser extends Command implements ICommand 
{
	static protected Class<?>[] arrayOfPossibleStateClasses = {StateNotConnectedNoUser.class};

	public CommandUser(String data, SessionContext sc) 
	{
		super(data, sc);
	}

	@Override
	// returns true if the username is validate
	protected void validate() throws SyntaxException, DataIncorrectException
	{
		String username = this.getData();
		if ((Utilities.getNumOfWordsInString(username) > 2) || (username.equals(null)))
		{
			// username can be only one name!
			throw new SyntaxException();
		}
		if (!username.equalsIgnoreCase("Eli"))
		{
			throw new DataIncorrectException();
		}
	}
	
	@Override
	// performs action and returns true if the action performed
	public void perform() throws SyntaxException, DataIncorrectException, StateException, InputException, OutputException
	{
		validateState();
		validate();
		String username = this.getData();
		getSessionContext().setUserName(username);
		getSessionContext().setState(new StateNotConnectedHasUserNoPsw());
		getSessionContext().sendMessageToClient(Constants.ErrorCodeUserOk);
		//TODO to delete old state from memory
	}
}
