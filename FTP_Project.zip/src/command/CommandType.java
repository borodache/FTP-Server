/*package command;

import server.SessionContext;
import util.Constants;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;

public class CommandType extends Command {

	public CommandType(String data, SessionContext sc) {
		super(data, sc);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void validate() throws SyntaxException, DataIncorrectException,
			DataPipeIsOpenedException {
		// TODO Auto-generated method stub

	}

	@Override
	public void perform() throws SyntaxException, DataIncorrectException,
			StateException, OutputException, InputException,
			DataPipeIsOpenedException, DataSocketInvalidException {
		this.getSessionContext().sendMessageToClient(Constants.ErrorCodeCommandOk);
	}
}*/
