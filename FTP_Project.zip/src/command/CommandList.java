package command;

import java.io.File;

import server.DataPipe;
import server.SessionContext;
import state.StateConnected;
import util.Constants;
import util.DataIncorrectException;
import util.DataPipeIsOpenedException;
import util.DataSocketInvalidException;
import util.InputException;
import util.OutputException;
import util.StateException;
import util.SyntaxException;
import util.Tracer;
import util.Utilities;

public class CommandList extends Command {

	static protected Class<?>[] arrayOfPossibleStateClasses = {StateConnected.class};
	
	public CommandList(String data, SessionContext sc) {
		super(data, sc);
	}

	@Override
	protected void validate() throws SyntaxException, DataIncorrectException, DataPipeIsOpenedException {
		String data = getData();
		if (Utilities.getNumOfWordsInString(data) > 1)
			throw new SyntaxException();
		if (getSessionContext().getDataPipe())
		{
			throw new DataPipeIsOpenedException();
		}
		if (data == null)
			return;
		File file = new File(data);
		if (!file.isDirectory())
			throw new DataIncorrectException();
	}

	@Override
	public void perform() throws SyntaxException, DataIncorrectException,
			StateException, OutputException, InputException, DataSocketInvalidException, DataPipeIsOpenedException {
		validateState();
		validate();

		String data = getData();
		SessionContext sc = this.getSessionContext();
		File folder;
		if (data == null)
		{
			folder = getSessionContext().getWorkingDirectory();
		}
		else
		{
		folder = new File(data);
		}
		String msg = "Directory:" + Constants.CRLF + folder + Constants.CRLF;
		for(int i = 0; i < folder.listFiles().length; i++)
		{
			msg = msg + ".." + folder.listFiles()[i].getName();
			if (i < (folder.listFiles().length - 1))
				msg = msg + Constants.CRLF;
		}
		Tracer.getInstance().printMessage("Send in data trasmition" + msg);
		DataPipe td = new DataPipe(sc, Constants.dynamicErrorCode(212,msg));
		td.start();
	}

}
