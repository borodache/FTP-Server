import java.io.*;
import java.net.*;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Socket s;
		System.err.println("Client Program");
		try {
			String string = "";
			do
			{
			InputStreamReader input = new InputStreamReader(System.in);
			BufferedReader reader = new BufferedReader(input);
			// read in user input 
			string = reader.readLine();
			s = new Socket("localhost", 21);
			s.getOutputStream().write(string.getBytes());
			s.close();
			} 
			while (!string.equals("exit"));
		} 
		catch (UnknownHostException e) 
		{
			// TODO Auto-generated catch block
			System.err.println("UnknownHostException");
			e.printStackTrace();
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			System.err.println("IOException");
			e.printStackTrace();
		}
	}
}
